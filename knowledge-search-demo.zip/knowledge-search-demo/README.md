# Knowledge Search Lab

A runnable BM25 retrieval baseline for exploring how knowledge assistants select source evidence.

**Independent portfolio demo.** New demonstration code, not company code or a production system.

## Run
Python 3.10 or newer. No dependencies or API keys.

```bash
python search.py "remote schedules"
python -m unittest discover -s tests -v
```

## Design
Query → tokenization → BM25 ranking → source documents and relevance scores.

Every result includes an ID, title, supporting text and score. Empty collections and queries without word overlap return no matches. Tests cover relevance, unsupported queries, normalization, limits and empty inputs.

## Tradeoffs
BM25 is a useful, inexpensive baseline before adding dense or hybrid retrieval. It is deterministic and easy to inspect, but misses synonyms and can match irrelevant passages sharing the same words. A match is not proof that the document answers a question.

## Scope
This is in-memory lexical search with sample policy documents. It does not call an LLM, generate answers, use embeddings, or provide authentication or persistence. Future extensions can add an evaluation dataset, dense retrieval, reranking and citation-aware generation. No production performance claims are made.
